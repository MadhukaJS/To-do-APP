package com.example.TodoAppServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoAppServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoAppServerApplication.class, args);
	}

}
